document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Exemplos de usuários e senhas válidas
    const validUsers = [
        { username: "login", password: "login" },
        { username: "login", password: "login" }
    ];

    let loginSuccessful = false;

    // Verifique se o usuário e a senha correspondem a um dos exemplos
    for (const user of validUsers) {
        if (username === user.username && password === user.password) {
            loginSuccessful = true;
            break;
        }
    }

    if (loginSuccessful) {
        // Redirecionar para a página 1 em caso de sucesso no login
        window.location.href = "http://teste1/home/";
    } else {
        // Mostrar a janela de erro
        document.getElementById("errorModal").style.display = "block";
    }
});

// Função para fechar a janela de erro
function closeErrorModal() {
    document.getElementById("errorModal").style.display = "none";
}
